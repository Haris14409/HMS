﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalSystem
{
    public partial class Staff_Add : Form
    {
        public Staff_Add()
        {
            InitializeComponent();
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            new Staff().Show();
            this.Hide();
        }
        StfClass stfc = new StfClass();
        private void Add_Pat_Details_btn_Click(object sender, EventArgs e)
        {
            try
            {
                stfc.insertStaff(Name_Txt.Text, Gender_Txt.Text, int.Parse(Age_Txt.Text), Convert.ToInt64(Contact_Txt.Text));
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
            
        }

        private void Staff_Add_Load(object sender, EventArgs e)
        {

        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
