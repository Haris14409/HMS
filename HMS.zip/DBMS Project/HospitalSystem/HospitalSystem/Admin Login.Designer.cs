﻿namespace HospitalSystem
{
    partial class Admin_Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroComboBox1 = new MetroFramework.Controls.MetroComboBox();
            this.TextBox1 = new MetroFramework.Controls.MetroTextBox();
            this.Tile1 = new MetroFramework.Controls.MetroTile();
            this.SuspendLayout();
            // 
            // metroComboBox1
            // 
            this.metroComboBox1.FormattingEnabled = true;
            this.metroComboBox1.ItemHeight = 23;
            this.metroComboBox1.Items.AddRange(new object[] {
            "Admin"});
            this.metroComboBox1.Location = new System.Drawing.Point(86, 87);
            this.metroComboBox1.Name = "metroComboBox1";
            this.metroComboBox1.Size = new System.Drawing.Size(121, 29);
            this.metroComboBox1.TabIndex = 0;
            this.metroComboBox1.UseSelectable = true;
            // 
            // TextBox1
            // 
            this.TextBox1.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.TextBox1.Lines = new string[0];
            this.TextBox1.Location = new System.Drawing.Point(86, 145);
            this.TextBox1.MaxLength = 32767;
            this.TextBox1.Name = "TextBox1";
            this.TextBox1.PasswordChar = '●';
            this.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TextBox1.SelectedText = "";
            this.TextBox1.Size = new System.Drawing.Size(121, 29);
            this.TextBox1.TabIndex = 1;
            this.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TextBox1.UseSelectable = true;
            this.TextBox1.UseSystemPasswordChar = true;
            // 
            // Tile1
            // 
            this.Tile1.ActiveControl = null;
            this.Tile1.Location = new System.Drawing.Point(110, 204);
            this.Tile1.Name = "Tile1";
            this.Tile1.Size = new System.Drawing.Size(75, 23);
            this.Tile1.TabIndex = 2;
            this.Tile1.Text = "Login";
            this.Tile1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Tile1.UseSelectable = true;
            this.Tile1.Click += new System.EventHandler(this.Tile1_Click);
            // 
            // Admin_Login
            // 
            this.AcceptButton = this.Tile1;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(296, 261);
            this.Controls.Add(this.Tile1);
            this.Controls.Add(this.TextBox1);
            this.Controls.Add(this.metroComboBox1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Admin_Login";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Style = MetroFramework.MetroColorStyle.Purple;
            this.Text = "Admin_Login";
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Load += new System.EventHandler(this.Admin_Login_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroComboBox metroComboBox1;
        private MetroFramework.Controls.MetroTextBox TextBox1;
        private MetroFramework.Controls.MetroTile Tile1;
    }
}