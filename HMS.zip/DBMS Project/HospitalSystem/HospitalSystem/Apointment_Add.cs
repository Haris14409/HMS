﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HospitalSystem
{
    public partial class Apointment_Add : Form
    {
        public Apointment_Add()
        {
            InitializeComponent();
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void Apointment_Add_Load(object sender, EventArgs e)
        {
            //dateTimePicker1.MinDate = DateTime.Now;
            //dateTimePicker1.MaxDate = DateTime.Now;
            //dateTimePicker2.MinDate = DateTime.Now;
            //dateTimePicker2.MaxDate = DateTime.Now.AddDays(30);
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            new Appointment().Show();
            this.Hide();
        }
        AptClass aptc = new AptClass();
        private void Add_btn_Click(object sender, EventArgs e)
        {
            try
            {
                aptc.onlyappointmentadd(int.Parse(comboBox1.Text), int.Parse(comboBox2.Text), dateTimePicker1.Text, int.Parse(comboBox3.Text), dateTimePicker2.Text, int.Parse(comboBox4.Text));
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Error : \nReason : "+ Ex.Message);
            }
        }

        private void Clear_Btn_Click(object sender, EventArgs e)
        {
            comboBox1.Text = null;
            comboBox2.Text = null;
            comboBox3.Text = null;
            comboBox4.Text = null;
            dateTimePicker1.Text = null;
            dateTimePicker2.Text = null;
        }

        private void comboBox1_MouseClick(object sender, MouseEventArgs e)
        {
            this.Size = new Size(580, 450);
        }

        Connection con = new Connection();
        SqlCommand cmd;
        SqlDataAdapter da;
        DataTable dt = new DataTable();
        private void comboBox1_Enter(object sender, EventArgs e)
        {
            gridView1.DataSource = null;
            dt = new DataTable();
            da = new SqlDataAdapter();
            cmd = new SqlCommand("select Patient_ID, Patient_name from Patients", con.Connect());
            cmd.ExecuteNonQuery();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            gridView1.DataSource = dt;
        }

        private void comboBox2_Enter(object sender, EventArgs e)
        {
            gridView1.DataSource = null;
            dt = new DataTable();
            da = new SqlDataAdapter();
            cmd = new SqlCommand("select doctor_ID, doctor_name from Doctors", con.Connect());
            cmd.ExecuteNonQuery();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            gridView1.DataSource = dt;
        }

        private void comboBox3_Enter(object sender, EventArgs e)
        {
            gridView1.DataSource = null;
            dt = new DataTable();
            da = new SqlDataAdapter();
            cmd = new SqlCommand("select appointment_type_ID, appointment_type_name from Appointment_types", con.Connect());
            cmd.ExecuteNonQuery();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            gridView1.DataSource = dt;
        }

        private void comboBox4_Enter(object sender, EventArgs e)
        {
            gridView1.DataSource = null;
            dt = new DataTable();
            da = new SqlDataAdapter();
            cmd = new SqlCommand("select lab_id, Lab_name from Labs", con.Connect());
            cmd.ExecuteNonQuery();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            gridView1.DataSource = dt;
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
