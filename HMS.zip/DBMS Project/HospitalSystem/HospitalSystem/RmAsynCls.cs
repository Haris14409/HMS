﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace HospitalSystem
{
    class RmAsynCls
    {
        Connection con = new Connection();
        SqlCommand cmd = null;
        SqlDataAdapter da = null;
        DataTable dt = new DataTable();

        public DataTable showRoomsAsyn()
        {
            cmd = new SqlCommand("select Room_Assign_ID , (select patient_name from Patients where patient_id = RA.patient_id) PatientName,(select Doctor_Name from Doctors D where RA.Doctor_ID = D.Doctor_ID) DoctorName, Room_ID,(select Staff_Name from Staff where Staff_ID = RA.Staff_ID) [Staff Name] ,(select Staff_Gender from Staff where Staff_ID = RA.staff_id) [Staff Gender], Room_Assign_Indate,Room_Assign_Outdate from Assigned_Rooms RA", con.Connect());
            cmd.ExecuteNonQuery();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            return dt;
        }

        public void deleteRoomsAssigned(int id)
        {
            try
            {
                cmd = new SqlCommand("delete from Assigned_Rooms where Room_Assign_ID=" + id + "", con.Connect());
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Assined Room deleted Successfully");
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message + "Assined Room Not Deleted");
                con.Close();
            }
        }

        public void insertRoomsAssigned(int patID,int docID,int rmID,int stfID,string rmAsyDate)
        {
            try
            {
                cmd = new SqlCommand("insert into Assigned_Rooms (Patient_ID,Doctor_ID,Room_ID,Staff_ID,Room_Assign_InDate) values(" + patID + "," + docID + "," + rmID + "," + stfID + ",'" + rmAsyDate + "')", con.Connect());
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Room Assigned Successfully");
            }
            catch (Exception E)
            {
                MessageBox.Show("Room Not Assigned  ! \nReason: \n" + E.Message);
                con.Close();
            }
        }

        public DataTable selectRmAsynID(int id)
        {
            try
            {
                cmd = new SqlCommand("exec selectRmAsynID " + id + "", con.Connect());
                cmd.ExecuteNonQuery();
                da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                con.Close();
                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in view appointments \nReason : " + ex.Message);
                con.Close();
            }
            return dt;
        }
        public DataTable fetcher(int id)
        {
            dt = new DataTable();
            try
            {
                cmd = new SqlCommand("select * from Assigned_Rooms where room_assign_id = " + id + "", con.Connect());
                cmd.ExecuteNonQuery();
                da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                con.Close();
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message);
                con.Close();
            }
            return dt;
        }

        public void updateRoomAsyn(int id,string outdate)
        {
            try
            {
                cmd = new SqlCommand("update Assigned_Rooms set Room_Assign_OutDate = '"+outdate+"' where Room_Assign_ID = "+id+"", con.Connect());
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Error in update. \nMake sure you enter IDs within Bounds. \n Reason : " + Ex.Message);
                con.Close();
            }
        }
    }
}
