﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace HospitalSystem
{
    class DeptClass
    {
        Connection con = new Connection();
        SqlCommand cmd = null;
        SqlDataAdapter da = null;
        DataTable dt = new DataTable();

        public DataTable showDept()
        {
            cmd = new SqlCommand("Select * from Departments", con.Connect());
            cmd.ExecuteNonQuery();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            return dt;
        }

        public void deleteDepartments(int id)
        {
            try
            {
                cmd = new SqlCommand("delete from Departments where id=" + id + "", con.Connect());
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Department deleted Successfully");
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message + "Department Not Deleted");
            }
        }

        public void insertDepartment(string deptname, int salary)
        {
            try
            {
                cmd = new SqlCommand("insert into Departments values ('" + deptname + "'," + salary + ")", con.Connect());
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Department Inserted !");
            }
            catch (Exception E)
            {
                MessageBox.Show("Department Not Inserted \nReason\n" + E.Message);
                con.Close();
            }
        }

        public DataTable selectDeptID(int id)
        {
            try
            {
                cmd = new SqlCommand("exec selectDeptID " + id + "", con.Connect());
                cmd.ExecuteNonQuery();
                da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                con.Close();
                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in view Departments \nReason : " + ex.Message);
                con.Close();
            }
            return dt;
        }
    }
}
