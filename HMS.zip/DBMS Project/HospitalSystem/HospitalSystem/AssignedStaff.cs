﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalSystem
{
    public partial class AssignedStaff : Form
    {
        public AssignedStaff()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new AdminPanel().Show();
            this.Hide();
        }
        AsynStfClass astfc = new AsynStfClass();
        DataTable dt = new DataTable();
        private void button1_Click(object sender, EventArgs e)
        {
            metroGrid1.DataSource = null;
            dt = astfc.showAsynStf();
            metroGrid1.DataSource = dt;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            astfc = new AsynStfClass();
            dt = null;
            metroGrid1.DataSource = null;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int id;
            try
            {
                if (metroGrid1.SelectedRows.Count == 1)
                {
                    int row = metroGrid1.CurrentRow.Index;
                    DataGridViewRow selectedRow = metroGrid1.Rows[row];
                    id = Convert.ToInt32(selectedRow.Cells["Staff_Assign_ID"].Value.ToString());
                    astfc.deleteAssignStaff(id);
                    MessageBox.Show(id.ToString());
                }
                else
                {
                    MessageBox.Show("No Row Selected !");
                }

            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            new Assign_Staff_Add().Show();
            this.Hide();
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void AssignedStaff_Load(object sender, EventArgs e)
        {

        }

        private void SearchBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == (char)Keys.Enter)
            {
                try
                {
                    metroGrid1.DataSource = null;
                    dt = astfc.selectAsynStaffID(int.Parse(SearchBox.Text));
                    metroGrid1.DataSource = dt;
                }
                catch (Exception Ex)
                {
                    MessageBox.Show("Error in Search! \nReason : " + Ex.Message);
                }
            }
        }
    }
}
