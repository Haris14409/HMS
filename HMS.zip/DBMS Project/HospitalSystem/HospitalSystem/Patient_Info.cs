﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalSystem
{
    public partial class Patient_Info : MetroFramework.Forms.MetroForm
    {
        public Patient_Info()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new Form1().Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        PatClass ptc = new PatClass();
        private void Patient_Info_Load(object sender, EventArgs e)
        {
            metroGrid1.DataSource = ptc.showPatients();
        }
        BlClass blc = new BlClass();
        private void button3_Click(object sender, EventArgs e)
        {
            int id;
            int nod = 0;
            try
            {
                if (metroGrid1.SelectedRows.Count == 1)
                {
                    int row = metroGrid1.CurrentRow.Index;
                    DataGridViewRow selectedRow = metroGrid1.Rows[row];
                    id = Convert.ToInt32(selectedRow.Cells["Patient ID"].Value.ToString());
                    nod = blc.findDays(id);
                    DialogResult dialog = MessageBox.Show("Do you want to generate the bill", "Warning", MessageBoxButtons.OKCancel);
                    if (dialog == DialogResult.OK)
                    {
                        blc.creatingbill(id,nod);
                       // MessageBox.Show("Successfully Bill Generated\nTotal Ammount: " + total);
                    }
                }
                else
                {
                    MessageBox.Show("No Row Selected !");
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }
        private void metroButton1_Click(object sender, EventArgs e)
        {
            
            new RA_Add("reception").Show();
            this.Hide();
        }
    }
}
