﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace HospitalSystem
{
    public partial class RA_Add : Form
    {
        public RA_Add()
        {
            InitializeComponent();
        }
        public RA_Add(string val)
        {
            value = val;
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        public string value;
        private void RA_Add_Load(object sender, EventArgs e)
        {
            try
            {
                dateTimePicker1.MaxDate = DateTime.Now;
                dateTimePicker1.MinDate = DateTime.Now;
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (value == "reception")
            {
                new Patient_Info().Show();
                this.Hide();
            }
            else
            {
                new Rooms_Assigned().Show();
                this.Hide();
            }            
        }
        RmAsynCls rmasc = new RmAsynCls();
        private void Btn_RA_Insert_Click(object sender, EventArgs e)
        {
            try
            {
                rmasc.insertRoomsAssigned(int.Parse(comboBox1.Text), int.Parse(comboBox2.Text), int.Parse(comboBox3.Text), int.Parse(comboBox4.Text), dateTimePicker1.Text);
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }            
        }
        Connection con = new Connection();
        SqlCommand cmd;
        SqlDataAdapter da;
        DataTable dt = new DataTable();
        private void comboBox1_Enter(object sender, EventArgs e)
        {
            gridview1.DataSource = null;
            dt = new DataTable();
            da = new SqlDataAdapter();
            cmd = new SqlCommand("select patient_id,patient_name from patients", con.Connect());
            cmd.ExecuteNonQuery();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            gridview1.DataSource = dt;
        }

        private void comboBox2_Enter(object sender, EventArgs e)
        {
            gridview1.DataSource = null;
            dt = new DataTable();
            da = new SqlDataAdapter();
            cmd = new SqlCommand("select doctor_id,doctor_name from doctors", con.Connect());
            cmd.ExecuteNonQuery();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            gridview1.DataSource = dt;
        }

        private void comboBox3_Enter(object sender, EventArgs e)
        {
            gridview1.DataSource = null;
            dt = new DataTable();
            da = new SqlDataAdapter();
            cmd = new SqlCommand("select Room_ID, Room_Type from rooms R join Room_Types RT on r.Room_Type_ID = RT.Room_Type_ID", con.Connect());
            cmd.ExecuteNonQuery();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            gridview1.DataSource = dt;
        }

        private void comboBox4_Enter(object sender, EventArgs e)
        {
            gridview1.DataSource = null;
            dt = new DataTable();
            da = new SqlDataAdapter();
            cmd = new SqlCommand("select staff_id,staff_name from Staff", con.Connect());
            cmd.ExecuteNonQuery();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            gridview1.DataSource = dt;
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
