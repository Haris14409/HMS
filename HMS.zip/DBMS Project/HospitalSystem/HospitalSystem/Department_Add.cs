﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalSystem
{
    public partial class Department_Add : Form
    {
        public Department_Add()
        {
            InitializeComponent();
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            new Departments().Show();
            this.Hide();
        }
        DeptClass dptc = new DeptClass();
        private void Add_Pat_Details_btn_Click(object sender, EventArgs e)
        {
            try
            {
                dptc.insertDepartment(Name_Txt.Text, int.Parse(numericUpDown1.Text));
                MessageBox.Show("Department Insert Successfully");
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
            
        }

        private void Department_Add_Load(object sender, EventArgs e)
        {

        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
