﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalSystem
{
    public partial class Rooms : Form
    {
        public Rooms()
        {
            InitializeComponent();
        }

        RmClass rmc = new RmClass();
        DataTable dt = new DataTable();
        private void button1_Click(object sender, EventArgs e)
        {
            metroGrid1.DataSource = null;
            dt = rmc.ShowRoom();
            metroGrid1.DataSource = dt;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new AdminPanel().Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            rmc = new RmClass();
            dt = null;
            metroGrid1.DataSource = null;
        }

        private void Dlt_RmsAsyn_Click(object sender, EventArgs e)
        {
            int id;
            try
            {
                if (metroGrid1.SelectedRows.Count == 1)
                {
                    int row = metroGrid1.CurrentRow.Index;
                    DataGridViewRow selectedRow = metroGrid1.Rows[row];
                    id = Convert.ToInt32(selectedRow.Cells["Room_ID"].Value.ToString());
                    //rmc.deleteRooms(id);
                    MessageBox.Show(id.ToString());
                }
                else
                {
                    MessageBox.Show("No Row Selected !");
                }

            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }

        private void Btn_RA_Insert_Click(object sender, EventArgs e)
        {
            new Rooms_Add().Show();
            this.Hide();
        }

        private void Rooms_Load(object sender, EventArgs e)
        {

        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void SearchBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == (char)Keys.Enter)
            {
                try
                {
                    metroGrid1.DataSource = null;
                    dt = rmc.selectRmID(int.Parse(SearchBox.Text));
                    metroGrid1.DataSource = dt;
                }
                catch (Exception Ex)
                {
                    MessageBox.Show("Error in Search! \nReason : " + Ex.Message);
                }
            }
        }
    }
}
