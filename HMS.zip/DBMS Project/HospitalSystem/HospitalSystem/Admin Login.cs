﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Forms;

namespace HospitalSystem
{
    public partial class Admin_Login : MetroFramework.Forms.MetroForm
    {
        public Admin_Login()
        {
            InitializeComponent();
        }

        private void Admin_Login_Load(object sender, EventArgs e)
        {

        }

        private void Tile1_Click(object sender, EventArgs e)
        {
            if (TextBox1.Text == "123")
            {
                new AdminPanel().Show();
                this.Hide();
            }
        }
    }
}
