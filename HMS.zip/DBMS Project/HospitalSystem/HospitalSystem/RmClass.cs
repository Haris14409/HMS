﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace HospitalSystem
{
    class RmClass
    {
        Connection con = new Connection();
        SqlCommand cmd = null;
        SqlDataAdapter da = null;
        DataTable dt = new DataTable();

        public DataTable ShowRoom()
        {
            cmd = new SqlCommand("SELECT Room_ID,No_of_Beds,(select Room_Type from Room_Types where Room_Type_ID=R.Room_Type_ID) as [Type Name] FROM Rooms R", con.Connect());
            cmd.ExecuteNonQuery();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            return dt;
        }
        public void deleteRooms(int id)
        {
            try
            {
                cmd = new SqlCommand("delete from Rooms where Room_ID=" + id + "", con.Connect());
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Rooms deleted Successfully");
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message + "Rooms Not Deleted");
            }
        }

        public void insertRoom(int nob,int rmTypID)
        {
            try
            {
                cmd = new SqlCommand("insert into Rooms values (" + nob + "," + rmTypID + ")", con.Connect());
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Room Inserted !");
            }
            catch (Exception E)
            {
                MessageBox.Show("Room Not Inserted \nReason\n" + E.Message);
                con.Close();
            }
        }

        public DataTable selectRmID(int id)
        {
            try
            {
                cmd = new SqlCommand("exec selectRmID " + id + "", con.Connect());
                cmd.ExecuteNonQuery();
                da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                con.Close();
                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in view Rooms \nReason : " + ex.Message);
                con.Close();
            }
            return dt;
        }
    }
}
