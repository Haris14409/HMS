﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace HospitalSystem
{
    class AsynStfClass
    {
        Connection con = new Connection();
        SqlCommand cmd = null;
        SqlDataAdapter da = null;
        DataTable dt = new DataTable();

        public DataTable showAsynStf()
        {
            cmd = new SqlCommand("Select Staff_Assign_ID,(select Staff_Name from Staff where Staff_ID=SA.Staff_ID) as [Staff Name],(select Department_Name from Departments D where Department_ID=SA.Department_ID) as [Department Name] from Staff_Assigned SA", con.Connect());
            cmd.ExecuteNonQuery();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            return dt;
        }

        public void deleteAssignStaff(int id)
        {
            try
            {
                cmd = new SqlCommand("delete from Staff_Assigned where Staff_Assign_ID = " + id + "", con.Connect());
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Assigned Staff deleted Successfully");
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message + "Assigned Staff Not Deleted");
            }
        }
        public void insertStaffAssigned(int staffID,int deptID)
        {
            try
            {
                cmd = new SqlCommand("insert into Staff_Assigned values(" + staffID + "," + deptID + ")", con.Connect());
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Staff Assigned Inserted !");
            }
            catch (Exception E)
            {
                MessageBox.Show("Not Inserted \nReason\n" + E.Message);
                con.Close();
            }
            
        }
        public DataTable selectAsynStaffID(int id)
        {
            try
            {
                cmd = new SqlCommand("exec selectasynstaffID " + id + "", con.Connect());
                cmd.ExecuteNonQuery();
                da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                con.Close();
                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in view Staff_Assigned \nReason : " + ex.Message);
                con.Close();
            }
            return dt;
        }

    }
}
