﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalSystem
{
    public partial class AdminPanel : Form
    {
        public AdminPanel()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void AdminPanel_Load(object sender, EventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {
        }
        private void appointmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }
        private void assignedStaffToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }
        private void doctorsToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }
        private void labsToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }
        private void roomsAssignedToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }
        private void patientsToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }
        private void departmentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }
        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
        }
        private void staffToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }
        private void roomsToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }
        private void billsToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
        }
        private void button3_Click(object sender, EventArgs e)
        {
            new Form1().Show();
            this.Hide();
        }
        private void button11_Click(object sender, EventArgs e)
        {
        }
        private void AssignedStaffBtn_Click(object sender, EventArgs e)
        {
            new AssignedStaff().Show();
            this.Hide();
        }
        private void AppointmentsBtn_Click(object sender, EventArgs e)
        {
            new Appointment().Show();
            this.Hide();
        }
        private void AssignedRoomsBtn_Click(object sender, EventArgs e)
        {
            new Rooms_Assigned().Show();
            this.Hide();
        }
        private void BillsBtn_Click(object sender, EventArgs e)
        {
            new Bills().Show();
            this.Hide();
        }
        private void DepartmentsBtn_Click(object sender, EventArgs e)
        {
            new Departments().Show();
            this.Hide();
        }
        private void DoctorsBtn_Click(object sender, EventArgs e)
        {
            new Doctors().Show();
            this.Hide();
        }
        private void DocSpecBtn_Click(object sender, EventArgs e)
        {
            new Doc_Special().Show();
            this.Hide();
        }
        private void LabsBtn_Click(object sender, EventArgs e)
        {
            new Labs().Show();
            this.Hide();
        }
        private void PatientsBtn_Click(object sender, EventArgs e)
        {
            new Patients().Show();
            this.Hide();
        }
        private void RoomsBtn_Click(object sender, EventArgs e)
        {
            new Rooms().Show();
            this.Hide();
        }
        private void StaffBtn_Click(object sender, EventArgs e)
        {
            new Staff().Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
