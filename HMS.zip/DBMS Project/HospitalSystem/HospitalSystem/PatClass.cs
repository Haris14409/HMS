﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace HospitalSystem
{
    class PatClass
    {
        Connection con = new Connection();
        SqlCommand cmd = null;
        SqlDataAdapter da = null;
        DataTable dt = new DataTable();

        public DataTable showPatients()
        {
            cmd = new SqlCommand("Select Patient_ID as [Patient ID],Patient_Name as [Name],Patient_Gender as [Gender],Patient_Age as [Age],Patient_Contact as [Contact],Patient_Disease as [Disease] from Patients", con.Connect());
            cmd.ExecuteNonQuery();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();

            return dt;
        }
        public void AddPatient(string name, string dname, int age, long cont, string prob)
        {
            try
            {
                cmd = new SqlCommand("insert into Patients values ('" + name + "','" + dname + "'," + age + "," + cont + ",'" + prob + "')", con.Connect());
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Successfully Entered");
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message.ToString());
                MessageBox.Show("Not Successfully Entered");
            }

        }

        public void deletePatients(int id)
        {
            try
            {
                cmd = new SqlCommand("delete from Patients where Patient_ID=" + id + "", con.Connect());
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Patient deleted Successfully");
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message + "Patient Not Deleted");
                con.Close();
            }
        }
        
        public DataTable selectPatID(int id)
        {
            try
            {
                cmd = new SqlCommand("exec selectPatientID " + id + "", con.Connect());
                cmd.ExecuteNonQuery();
                da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                con.Close();
                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in view Patients \nReason : " + ex.Message);
                con.Close();
            }
            return dt;
        }
    }
}


