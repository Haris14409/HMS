﻿namespace HospitalSystem
{
    partial class AdminPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminPanel));
            this.button6 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.BackBtn = new System.Windows.Forms.Button();
            this.AssignedStaffBtn = new System.Windows.Forms.Button();
            this.DoctorsBtn = new System.Windows.Forms.Button();
            this.LabsBtn = new System.Windows.Forms.Button();
            this.AssignedRoomsBtn = new System.Windows.Forms.Button();
            this.PatientsBtn = new System.Windows.Forms.Button();
            this.DepartmentsBtn = new System.Windows.Forms.Button();
            this.RoomsBtn = new System.Windows.Forms.Button();
            this.StaffBtn = new System.Windows.Forms.Button();
            this.BillsBtn = new System.Windows.Forms.Button();
            this.AppointmentsBtn = new System.Windows.Forms.Button();
            this.DocSpecBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.Crimson;
            this.button6.Location = new System.Drawing.Point(1287, 13);
            this.button6.Margin = new System.Windows.Forms.Padding(4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(30, 28);
            this.button6.TabIndex = 5;
            this.button6.Text = "X";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.MidnightBlue;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.ImageLocation = "";
            this.pictureBox1.Location = new System.Drawing.Point(1, 2);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(898, 181);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(1193, 561);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(124, 39);
            this.button1.TabIndex = 13;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.ForeColor = System.Drawing.Color.Crimson;
            this.button2.Location = new System.Drawing.Point(862, 13);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(26, 24);
            this.button2.TabIndex = 14;
            this.button2.Text = "X";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // BackBtn
            // 
            this.BackBtn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackBtn.Location = new System.Drawing.Point(783, 454);
            this.BackBtn.Name = "BackBtn";
            this.BackBtn.Size = new System.Drawing.Size(105, 39);
            this.BackBtn.TabIndex = 15;
            this.BackBtn.Text = "Back";
            this.BackBtn.UseVisualStyleBackColor = true;
            this.BackBtn.Click += new System.EventHandler(this.button3_Click);
            // 
            // AssignedStaffBtn
            // 
            this.AssignedStaffBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AssignedStaffBtn.Location = new System.Drawing.Point(125, 233);
            this.AssignedStaffBtn.Name = "AssignedStaffBtn";
            this.AssignedStaffBtn.Size = new System.Drawing.Size(137, 40);
            this.AssignedStaffBtn.TabIndex = 16;
            this.AssignedStaffBtn.Text = "Assigned Staff";
            this.AssignedStaffBtn.UseVisualStyleBackColor = true;
            this.AssignedStaffBtn.Click += new System.EventHandler(this.AssignedStaffBtn_Click);
            // 
            // DoctorsBtn
            // 
            this.DoctorsBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DoctorsBtn.Location = new System.Drawing.Point(301, 307);
            this.DoctorsBtn.Name = "DoctorsBtn";
            this.DoctorsBtn.Size = new System.Drawing.Size(137, 40);
            this.DoctorsBtn.TabIndex = 17;
            this.DoctorsBtn.Text = "Doctors";
            this.DoctorsBtn.UseVisualStyleBackColor = true;
            this.DoctorsBtn.Click += new System.EventHandler(this.DoctorsBtn_Click);
            // 
            // LabsBtn
            // 
            this.LabsBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabsBtn.Location = new System.Drawing.Point(655, 307);
            this.LabsBtn.Name = "LabsBtn";
            this.LabsBtn.Size = new System.Drawing.Size(137, 40);
            this.LabsBtn.TabIndex = 18;
            this.LabsBtn.Text = "Labs";
            this.LabsBtn.UseVisualStyleBackColor = true;
            this.LabsBtn.Click += new System.EventHandler(this.LabsBtn_Click);
            // 
            // AssignedRoomsBtn
            // 
            this.AssignedRoomsBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AssignedRoomsBtn.Location = new System.Drawing.Point(301, 233);
            this.AssignedRoomsBtn.Name = "AssignedRoomsBtn";
            this.AssignedRoomsBtn.Size = new System.Drawing.Size(137, 40);
            this.AssignedRoomsBtn.TabIndex = 19;
            this.AssignedRoomsBtn.Text = "Assigned Rooms";
            this.AssignedRoomsBtn.UseVisualStyleBackColor = true;
            this.AssignedRoomsBtn.Click += new System.EventHandler(this.AssignedRoomsBtn_Click);
            // 
            // PatientsBtn
            // 
            this.PatientsBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PatientsBtn.Location = new System.Drawing.Point(200, 380);
            this.PatientsBtn.Name = "PatientsBtn";
            this.PatientsBtn.Size = new System.Drawing.Size(137, 40);
            this.PatientsBtn.TabIndex = 20;
            this.PatientsBtn.Text = "Patients";
            this.PatientsBtn.UseVisualStyleBackColor = true;
            this.PatientsBtn.Click += new System.EventHandler(this.PatientsBtn_Click);
            // 
            // DepartmentsBtn
            // 
            this.DepartmentsBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DepartmentsBtn.Location = new System.Drawing.Point(125, 307);
            this.DepartmentsBtn.Name = "DepartmentsBtn";
            this.DepartmentsBtn.Size = new System.Drawing.Size(137, 40);
            this.DepartmentsBtn.TabIndex = 21;
            this.DepartmentsBtn.Text = "Departments";
            this.DepartmentsBtn.UseVisualStyleBackColor = true;
            this.DepartmentsBtn.Click += new System.EventHandler(this.DepartmentsBtn_Click);
            // 
            // RoomsBtn
            // 
            this.RoomsBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RoomsBtn.Location = new System.Drawing.Point(389, 380);
            this.RoomsBtn.Name = "RoomsBtn";
            this.RoomsBtn.Size = new System.Drawing.Size(137, 40);
            this.RoomsBtn.TabIndex = 23;
            this.RoomsBtn.Text = "Rooms";
            this.RoomsBtn.UseVisualStyleBackColor = true;
            this.RoomsBtn.Click += new System.EventHandler(this.RoomsBtn_Click);
            // 
            // StaffBtn
            // 
            this.StaffBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StaffBtn.Location = new System.Drawing.Point(575, 380);
            this.StaffBtn.Name = "StaffBtn";
            this.StaffBtn.Size = new System.Drawing.Size(137, 40);
            this.StaffBtn.TabIndex = 24;
            this.StaffBtn.Text = "Staff";
            this.StaffBtn.UseVisualStyleBackColor = true;
            this.StaffBtn.Click += new System.EventHandler(this.StaffBtn_Click);
            // 
            // BillsBtn
            // 
            this.BillsBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BillsBtn.Location = new System.Drawing.Point(655, 233);
            this.BillsBtn.Name = "BillsBtn";
            this.BillsBtn.Size = new System.Drawing.Size(137, 40);
            this.BillsBtn.TabIndex = 25;
            this.BillsBtn.Text = "Bills";
            this.BillsBtn.UseVisualStyleBackColor = true;
            this.BillsBtn.Click += new System.EventHandler(this.BillsBtn_Click);
            // 
            // AppointmentsBtn
            // 
            this.AppointmentsBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AppointmentsBtn.Location = new System.Drawing.Point(479, 233);
            this.AppointmentsBtn.Name = "AppointmentsBtn";
            this.AppointmentsBtn.Size = new System.Drawing.Size(137, 40);
            this.AppointmentsBtn.TabIndex = 26;
            this.AppointmentsBtn.Text = "Appoinments";
            this.AppointmentsBtn.UseVisualStyleBackColor = true;
            this.AppointmentsBtn.Click += new System.EventHandler(this.AppointmentsBtn_Click);
            // 
            // DocSpecBtn
            // 
            this.DocSpecBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DocSpecBtn.Location = new System.Drawing.Point(479, 307);
            this.DocSpecBtn.Name = "DocSpecBtn";
            this.DocSpecBtn.Size = new System.Drawing.Size(137, 40);
            this.DocSpecBtn.TabIndex = 27;
            this.DocSpecBtn.Text = "Doctor Special";
            this.DocSpecBtn.UseVisualStyleBackColor = true;
            this.DocSpecBtn.Click += new System.EventHandler(this.DocSpecBtn_Click);
            // 
            // AdminPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(900, 505);
            this.Controls.Add(this.DocSpecBtn);
            this.Controls.Add(this.AppointmentsBtn);
            this.Controls.Add(this.BillsBtn);
            this.Controls.Add(this.StaffBtn);
            this.Controls.Add(this.RoomsBtn);
            this.Controls.Add(this.DepartmentsBtn);
            this.Controls.Add(this.PatientsBtn);
            this.Controls.Add(this.AssignedRoomsBtn);
            this.Controls.Add(this.LabsBtn);
            this.Controls.Add(this.DoctorsBtn);
            this.Controls.Add(this.AssignedStaffBtn);
            this.Controls.Add(this.BackBtn);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "AdminPanel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminPanel";
            this.Load += new System.EventHandler(this.AdminPanel_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button BackBtn;
        private System.Windows.Forms.Button AssignedStaffBtn;
        private System.Windows.Forms.Button DoctorsBtn;
        private System.Windows.Forms.Button LabsBtn;
        private System.Windows.Forms.Button AssignedRoomsBtn;
        private System.Windows.Forms.Button PatientsBtn;
        private System.Windows.Forms.Button DepartmentsBtn;
        private System.Windows.Forms.Button RoomsBtn;
        private System.Windows.Forms.Button StaffBtn;
        private System.Windows.Forms.Button BillsBtn;
        private System.Windows.Forms.Button AppointmentsBtn;
        private System.Windows.Forms.Button DocSpecBtn;
    }
}