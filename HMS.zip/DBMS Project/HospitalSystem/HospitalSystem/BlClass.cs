﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;
using System.IO;

namespace HospitalSystem
{
    class BlClass
    {
        Connection con = new Connection();
        SqlCommand cmd = null;
        SqlDataAdapter da = null;
        DataTable dt = new DataTable();

        public DataTable ShowBills()
        {
            cmd = new SqlCommand("select * from Billings", con.Connect());
            cmd.ExecuteNonQuery();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            return dt;
        }
        public void deleteBills(int id)
        {
            try
            {
                cmd = new SqlCommand("delete from Billings where Bill_id=" + id + "", con.Connect());
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Bill deleted Successfully");
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message + "Bill Not Deleted");
                con.Close();
            }
        }
        public void creatingbill(int id,int nod)
        {
            int sum = 0;
            int aptfees = 0;
            int roomPday = 0;
            int labCharg = 0;
            try
            {
                dt = new DataTable();
                cmd = new SqlCommand("exec create_bill "+id+","+nod+"", con.Connect());
                cmd.ExecuteNonQuery();
                da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                con.Close();
                aptfees = int.Parse(dt.Rows[0][0].ToString());
                roomPday = int.Parse(dt.Rows[0][1].ToString());
                labCharg = int.Parse(dt.Rows[0][2].ToString());
                sum = int.Parse(dt.Rows[0][3].ToString());
                //MessageBox.Show("Total Bill\n\n               Patient ID : " + id + "\n\nAppointment Fees : " + aptfees + "\nRoom Per Day : " + roomPday + "\nTotal No of Days : " + nod + "\nLab Charges : " + labCharg + "\n\n\n     Total Bill Ammount = " + sum + "");
                StreamWriter File = new StreamWriter(@"C:\Users\Bente\Desktop\Bill.txt");
                File.Write("Total Bill\n\n               Patient ID: " + id + "\n\nAppointment Fees: " + aptfees + "\nRoom Per Day: " + roomPday + "\nTotal No of Days: " + nod + "\nLab Charges: " + labCharg + "\n\n\n     Total Bill Ammount = " + sum + "");
                File.Close();
                MessageBox.Show("Bill Generated Successfully! :D :P :v ;) :)");

            }
            catch (Exception Ex)
            {
                MessageBox.Show("Error \nReason : " + Ex.Message);
            }
        }
        static int findSum(int[] A, int N)
        {
            if (N <= 0)
                return 0;
            return (findSum(A, N - 1) + A[N - 1]);
        }

        public DataTable selectBilID(int id)
        {
            try
            {
                cmd = new SqlCommand("select * from Billings where Bill_id = " + id + "", con.Connect());
                cmd.ExecuteNonQuery();
                da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                con.Close();
                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in view Bills \nReason : " + ex.Message);
                con.Close();
            }
            return dt;
        }

        public int findDays(int id)
        {
            int count = 0;
            dt = assignDays(id);
            try
            {
                string d1 = dt.Rows[0][0].ToString();
                string d2 = dt.Rows[0][1].ToString();
                if (d1 != "" && d2 != "")
                {
                    DateTime date1 = Convert.ToDateTime(d1);
                    DateTime date2 = Convert.ToDateTime(d2);

                    TimeSpan ts = date2.Subtract(date1);
                    count = Convert.ToInt32(ts.Days.ToString());
                }
            }
            catch (Exception Ex)
            {
               MessageBox.Show("Error in Assign Day \nReason : " + Ex.Message);
            }
            return count;
        }

        public DataTable assignDays(int id)
        {
            dt = new DataTable();
            try
            {
                cmd = new SqlCommand("select Room_Assign_InDate,Room_Assign_OutDate from Assigned_Rooms where patient_id = " + id + " ", con.Connect());
                cmd.ExecuteNonQuery();
                da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                con.Close();
                
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Error in DateGenerater . \nReason :" + Ex.Message);
                con.Close();
            }
            return dt;
        }
    }
}
