﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalSystem
{
    public partial class Rooms_Assigned : Form
    {
        public Rooms_Assigned()
        {
            InitializeComponent();
        }

        private void Rooms_Assigned_Load(object sender, EventArgs e)
        {
            dateTimePicker1.MinDate = DateTime.Now;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new AdminPanel().Show();
            this.Hide();
        }
        RmAsynCls rmac = new RmAsynCls();
        DataTable dt = new DataTable();
        private void button3_Click(object sender, EventArgs e)
        {
            rmac = new RmAsynCls();
            dt = null;
            metroGrid1.DataSource = null;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            metroGrid1.DataSource = null;
            dt = rmac.showRoomsAsyn();
            metroGrid1.DataSource = dt;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Btn_RA_Insert_Click(object sender, EventArgs e)
        {
            new RA_Add().Show();
            this.Hide();
        }

        private void Dlt_RmsAsyn_Click(object sender, EventArgs e)
        {
            int id;
            try
            {
                if (metroGrid1.SelectedRows.Count > 0)
                {
                    int row = metroGrid1.CurrentRow.Index;
                    DataGridViewRow selectedRow = metroGrid1.Rows[row];
                    id = Convert.ToInt32(selectedRow.Cells["Room_Assign_ID"].Value.ToString());
                    //rmac.deleteRoomsAssigned(id);
                    MessageBox.Show(id.ToString());
                }
                else
                {
                    MessageBox.Show("No Row Selected !");
                }

            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }

        }

        private void SearchBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == (char)Keys.Enter)
            {
                try
                {
                    metroGrid1.DataSource = null;
                    dt  = rmac.selectRmAsynID(int.Parse(SearchBox.Text));
                    metroGrid1.DataSource = dt;
                }
                catch (Exception Ex)
                {
                    MessageBox.Show("Error in Search! \nReason : " + Ex.Message);
                }
            }
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        
        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                metroLabel2.Visible = true;
                metroLabel3.Visible = true;
                TextBox1.Visible = true;
                dateTimePicker1.Visible = true;
                button4.Visible = false;
                button5.Visible = true;
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Error in Update Room Assigned. \nReason : " + Ex.Message);
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            dt = rmac.fetcher(int.Parse(TextBox1.Text));
            TextBox2.Text = dt.Rows[0][0].ToString();
            if (TextBox2.Text != "")
            {
                rmac.updateRoomAsyn(int.Parse(TextBox1.Text), dateTimePicker1.Text);
                MessageBox.Show("Update Successful!!");
            }
        }
    }
}

