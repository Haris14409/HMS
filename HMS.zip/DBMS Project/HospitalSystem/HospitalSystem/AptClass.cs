﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

//first uper 3 liberary call hongi 
namespace HospitalSystem
{
    class AptClass
    {
        // then ye 3 objects banainge 
        // connection ki class ka 
        Connection con = new Connection();
        // sql command ka
        SqlCommand cmd = new SqlCommand();
        // sql dataadapter ka
        // sql dataadapter ek adapter ki trah kaam krta k data ko fill krwane me help krta
        // kisi bhi extension me jese datatable ya dataset me
        SqlDataAdapter da = new SqlDataAdapter();
        DataTable dt = new DataTable();
        // ye wo function ha jahan me show ki command chala raha 
        // isme hi me decide bhi kr raha k ager wahan se koi command aye first parameter
        // me tou specific coloums do mujhe warna saray column dikha do
        public DataTable viewAppointment()
        {
            try
            {
                cmd = new SqlCommand("select Appointment_id,(select patient_name from Patients P where A.patient_id = P.patient_id) PatientName,(select doctor_name from Doctors D where A.doctor_id = D.doctor_id) DoctorName,[Date],Appointment_type_id,Appointment_datetime from Appointments A", con.Connect());
                // koi bhi query ko chalane k liay executenonquery use hota compiler ko 
                //batane k liay k ye query type command ha
                cmd.ExecuteNonQuery();
                da = new SqlDataAdapter(cmd);
                //data datatable me es trah dalta ha
                da.Fill(dt);
                //kaam krne k baad connection close krna lazmi
                con.Close();

                //akhir me datatable type return krwai
                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in view appointments \nReason : " + ex.Message);
                con.Close();
            }
            return dt;
        }

        public void insertAppointment(string patname,string patgend,int patage,long patcont,string patdeseas,int docID,string date,string aptype,string aptdate,string labname)
        {
            try
            {
                cmd = new SqlCommand("exec AddAppointment '" + patname + "','" + patgend + "'," + patage + "," + patcont + ",'" + patdeseas + "'," + docID + ",'" + date + "','" + aptype + "','" + aptdate + "','" + labname + "'", con.Connect());
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Appointment Successfully Entered");
            }
            catch (Exception E)
            {
                MessageBox.Show("Appointment not added ! \nReason : " + E.Message);
                con.Close();
            }
        }

        public void deleteAppointment(int id)
        {
            try
            {
                cmd = new SqlCommand("delete from Appointments where appointment_id=" + id + "", con.Connect());
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Appointment deleted Successfully");
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message + "Appointment Not Deleted");
            }
        }

        public void onlyappointmentadd(int patID,int docID,string date,int typeID,string aptdate,int labID)
        {
            try
            {
                cmd = new SqlCommand("insert into Appointments values(0, 0, '', 0, '', 0)", con.Connect());
                cmd.ExecuteNonQuery();
                con.Close();

            }
            catch (Exception E)
            {
                MessageBox.Show("Not Inserted \nReason : " + E.Message);
            }
        }

        public DataTable selectaptid(int id)
        {
            try
            {
                cmd = new SqlCommand("selectAptID " + id + "", con.Connect());
                cmd.ExecuteNonQuery();
                da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                con.Close();
                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in view appointments \nReason : " + ex.Message);
                con.Close();
            }
            return dt;
        }
        DataSet ds = new DataSet();
        public DataSet fetcher(int id)
        {
            try
            {
                cmd = new SqlCommand("select * from Appointments where appointment_id = " + id + "", con.Connect());
                cmd.ExecuteNonQuery();
                da = new SqlDataAdapter(cmd);
                da.Fill(ds, "Appointments");
                con.Close();
            }
            catch (Exception EX)
            {
                MessageBox.Show(EX.Message);
                con.Close();
            }
            return ds;
        }

        public void updateappointments(int patID,int docID,string date,int aptype,string aptdate,int appointmentID)
        {
            try
            {
                cmd = new SqlCommand("update Appointments set  [Patient_ID] = "+patID+" ,Doctor_ID = "+docID+" ,[Date] = '"+date+"' , Appointment_Type_ID = "+aptype+", Appointment_DateTime='"+aptdate+"' where Appointment_ID = "+appointmentID+"", con.Connect());
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Error in update. \nMake sure you enter IDs within Bounds. \n Reason : " + Ex.Message);
                con.Close();
            }
        }
    }
}
