﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace HospitalSystem
{
    class DcSpClass
    {
        Connection con = new Connection();
        SqlCommand cmd = null;
        SqlDataAdapter da = null;
        DataTable dt = new DataTable();

        public DataTable Doctor_Specialization()
        {
            cmd = new SqlCommand("select b.Doctor_Special_ID as ID, a.Doctor_Name as Name,b.Doctor_Special as Specialization from Doctors a join Doctor_Specializations b on a.Doctor_ID = b.Doctor_ID", con.Connect());
            cmd.ExecuteNonQuery();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            return dt;
        }

        public void deleteDoctorSpecialization(int id)
        {
            try
            {
                cmd = new SqlCommand("delete from Doctor_Specialization where id=" + id + "", con.Connect());
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Doctor Specialization deleted Successfully");
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message + "\nDoctor Specialization Not Deleted");
            }
        }

        public void insertDoctorSpecialization(int docID,string docSpec)
        {
            try
            {
                cmd = new SqlCommand("insert into Doctor_Specializations values (" + docID + ",'" + docSpec + "')", con.Connect());
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Doctor Specialization Inserted !");
            }
            catch (Exception E)
            {
                MessageBox.Show("Doctor Specialization Not Inserted \nReason:\n" + E.Message);
                con.Close();
            }
        }

        public DataTable selectDocSpecID(int id)
        {
            try
            {
                cmd = new SqlCommand("exec selectDocSpID " + id + "", con.Connect());
                cmd.ExecuteNonQuery();
                da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                con.Close();
                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in view Doctor_Specializations \nReason : " + ex.Message);
                con.Close();
            }
            return dt;
        }

        public DataTable DocSpecInfo(int id)
        {
            try
            {
                cmd = new SqlCommand("select (select doctor_name from doctors d where ds.doctor_id=d.doctor_id) [Doctor Name],Doctor_special as [Specialization Name] from Doctor_Specializations ds where doctor_id = " + id + "", con.Connect());
                cmd.ExecuteNonQuery();
                da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                con.Close();
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Error in select Specialization ID \nReason : " + Ex.Message);
            }
            return dt;
        }
    }
}
