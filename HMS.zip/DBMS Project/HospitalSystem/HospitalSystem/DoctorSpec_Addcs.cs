﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HospitalSystem
{
    public partial class DoctorSpec_Addcs : Form
    {
        public DoctorSpec_Addcs()
        {
            InitializeComponent();
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            new Doc_Special().Show();
            this.Hide();
        }
        DcSpClass dcspc = new DcSpClass();
        private void Add_Pat_Details_btn_Click(object sender, EventArgs e)
        {
            try
            {
                dcspc.insertDoctorSpecialization(int.Parse(comboBox1.Text), Name_Txt.Text);
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }

        private void DoctorSpec_Addcs_Load(object sender, EventArgs e)
        {
          
        }
        Connection con = new Connection();
        SqlCommand cmd;
        SqlDataAdapter da;
        DataTable dt = new DataTable();
        private void comboBox1_Enter(object sender, EventArgs e)
        {
            gridView1.DataSource = null;
            dt = new DataTable();
            da = new SqlDataAdapter();
            cmd = new SqlCommand("select doctor_id as ID,doctor_name as Name from doctors", con.Connect());
            cmd.ExecuteNonQuery();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            gridView1.DataSource = dt;
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
