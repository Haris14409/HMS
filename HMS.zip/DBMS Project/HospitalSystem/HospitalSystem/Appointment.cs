﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalSystem
{
    public partial class Appointment : Form
    {
        public Appointment()
        {
            InitializeComponent();
        }
        //go back button
        private void button2_Click(object sender, EventArgs e)
        {
            new AdminPanel().Show();
            this.Hide();
        }
        // ye meri class ha appointment ki jisme mene public funtions call krwaye hain
        //unko use krke me data get kr raha sql se
        AptClass aptc = new AptClass();
        //ye system.data ki liberary se call hota ha isme ap sql se data utha k save krte
        //data grid me show krne k liay 
        DataTable dt = new DataTable();
        //show gridview button
        private void button1_Click(object sender, EventArgs e)
        {
            metroGrid1.DataSource = null;
            dt = aptc.viewAppointment();
            metroGrid1.DataSource = dt;
        }
        //clear button 
        private void button3_Click(object sender, EventArgs e)
        {
            aptc = new AptClass();
            dt = null;
            metroGrid1.DataSource = null;
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            int id;
            try
            {
                if (metroGrid1.SelectedRows.Count == 1)
                {
                    int row = metroGrid1.CurrentRow.Index;
                    DataGridViewRow selectedRow = metroGrid1.Rows[row];
                    id = Convert.ToInt32(selectedRow.Cells["Appointment_ID"].Value.ToString());
                    //aptc.deleteAppointment(id);
                    MessageBox.Show(id.ToString());
                }
                else
                {
                    MessageBox.Show("No Row Selected !");
                }

            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }

        private void Appointment_Load(object sender, EventArgs e)
        {

        }

        private void insertApt_Click(object sender, EventArgs e)
        {
            new Apointment_Add().Show();
            this.Hide();
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void SearchBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == (char)Keys.Enter)
            {
                try
                {
                    metroGrid1.DataSource = null;
                    dt = aptc.selectaptid(int.Parse(SearchBox.Text));
                    metroGrid1.DataSource = dt;
                }
                catch (Exception Ex)
                {
                    MessageBox.Show("Error in Search! \nReason : " + Ex.Message);
                }
            }
        }
        int counter = 0;
        DataSet ds = new DataSet();
        private void UpdateBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (counter > 0)
                {
                    aptc.updateappointments(int.Parse(TextBox2.Text), int.Parse(TextBox3.Text), TextBox4.Text, int.Parse(TextBox5.Text), TextBox6.Text, int.Parse(TextBox1.Text));
                    MessageBox.Show("Update Successful!!");
                }
                if (TextBox1.Text == "")
                {
                    metroLabel2.Visible = true;
                    TextBox1.Visible = true;
                }
                else if (TextBox1.Text != "" && TextBox2.Text == "")
                {
                    ds = aptc.fetcher(int.Parse(TextBox1.Text));
                    TextBox2.Text = ds.Tables["Appointments"].Rows[0][1].ToString();
                    TextBox3.Text = ds.Tables["Appointments"].Rows[0][2].ToString();
                    TextBox4.Text = ds.Tables["Appointments"].Rows[0][3].ToString();
                    TextBox5.Text = ds.Tables["Appointments"].Rows[0][4].ToString();
                    TextBox6.Text = ds.Tables["Appointments"].Rows[0][5].ToString();
                }
                if (TextBox1.Text != "" && TextBox2.Text != "" && TextBox3.Text != "" && TextBox4.Text != "" && TextBox5.Text != "" && TextBox6.Text != "")
                {
                    metroLabel2.Visible = true;
                    metroLabel3.Visible = true;
                    metroLabel4.Visible = true;
                    metroLabel5.Visible = true;
                    metroLabel6.Visible = true;
                    metroLabel7.Visible = true;
                    TextBox2.Visible = true;
                    TextBox3.Visible = true;
                    TextBox4.Visible = true;
                    TextBox5.Visible = true;
                    TextBox6.Visible = true;
                    counter++;
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Error in Update Appointment. \nReason : " + Ex.Message);
            }
            
        }

        private void metroGrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void SearchBox_Click(object sender, EventArgs e)
        {

        }
    }
}
