﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace HospitalSystem
{
    class DocClass
    {
        Connection con = new Connection();
        SqlCommand cmd = null;
        SqlDataAdapter da = null;
        DataTable dt = new DataTable();

        public DataTable showDoc()
        {
            cmd = new SqlCommand("Select Doctor_ID as [Doctor ID],Doctor_Name as [Name],Doctor_Gender as [Gender],Doctor_Age as [Age],Doctor_Contact as [Contact],Doctor_Qualification as [Qualification] from Doctors", con.Connect());
            cmd.ExecuteNonQuery();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();

            return dt;
        }

        public void deleteDoctors(int id)
        {
            try
            {
                cmd = new SqlCommand("delete from Doctors where id=" + id + "", con.Connect());
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Doctor deleted Successfully");
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message + "Doctor Not Deleted");
                con.Close();
            }
        }

        public DataTable selectDocID(int id)
        {
            try
            {
                cmd = new SqlCommand("exec selectDocID " + id + "", con.Connect());
                cmd.ExecuteNonQuery();
                da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                con.Close();
                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in view Doctors. \nReason : " + ex.Message);
                con.Close();
            }
            return dt;
        }
    }
}
