﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace HospitalSystem
{
    class LbClass
    {
        Connection con = new Connection();
        SqlCommand cmd = null;
        SqlDataAdapter da = null;
        DataTable dt = new DataTable();

        public DataTable showLab()
        {
            cmd = new SqlCommand("select Lab_ID,Lab_Name,Lab_Charges,(select staff_name from Staff where Staff_ID=L.Staff_ID) as [Lab Assistant Name] from Labs L", con.Connect());
            cmd.ExecuteNonQuery();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();

            return dt;
        }
        public void LabAdd(string lbname,string lbcharg,int staffID)
        {
            try
            {
                cmd = new SqlCommand("insert into Labs values('" + lbname + "'," + lbcharg + "," + staffID + ")", con.Connect());
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Lab Entered Successfully");
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message + "\nLab Not Entered");
            }
        }

        public void deleteLabs(int id)
        {
            try
            {
                cmd = new SqlCommand("delete from Labs where lab_id=" + id + "", con.Connect());
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Lab deleted Successfully");
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message + "Lab Not Deleted");
            }
        }

        public void insertStaffAssigned(string lbname,int lbcharg,int stfID)
        {
            try
            {
                cmd = new SqlCommand("insert into Labs values ('" + lbname + "'," + lbcharg + "," + stfID + ")", con.Connect());
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Lab Inserted !");
            }
            catch (Exception E)
            {
                MessageBox.Show("Lab Not Inserted \nReason\n" + E.Message);
                con.Close();
            }

        }

        public DataTable selectLabID(int id)
        {
            try
            {
                cmd = new SqlCommand("exec selectLabID " + id + "", con.Connect());
                cmd.ExecuteNonQuery();
                da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                con.Close();
                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in view Labs. \nReason : " + ex.Message);
                con.Close();
            }
            return dt;
        }
    }
}
