﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HospitalSystem
{
    public partial class Appointment_Add : Form
    {
        public Appointment_Add()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new Form1().Show();
            this.Hide();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        PatClass ptc = new PatClass();
        

        private void Appointment_Add_Load(object sender, EventArgs e)
        {
            dateTimePicker1.MinDate = DateTime.Now;
            dateTimePicker1.MaxDate = DateTime.Now;
            dateTimePicker2.MinDate = DateTime.Now;
            dateTimePicker2.MaxDate = DateTime.Now.AddDays(30);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            comboBox3.Text = null;
        }
        AptClass aptc = new AptClass();
        private void apt_add_btn_Click(object sender, EventArgs e)
        {
            try
            {
                aptc.insertAppointment(textBox1.Text, textBox2.Text, int.Parse(textBox3.Text), Convert.ToInt64(textBox4.Text), textBox5.Text, int.Parse(comboBox4.Text), dateTimePicker1.Text, comboBox2.Text, dateTimePicker2.Text, comboBox3.Text);
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }

        private void patient_add_btn_Click(object sender, EventArgs e)
        {

        }
        Connection con = new Connection();
        SqlCommand cmd;
        SqlDataAdapter da;
        DataTable dt = new DataTable();
        private void comboBox1_Enter(object sender, EventArgs e)
        {
            gridView1.DataSource = null;
            dt = new DataTable();
            da = new SqlDataAdapter();
            cmd = new SqlCommand("select a.Doctor_ID as [Doctor ID],b.Doctor_Name as [Doctor Name] From Doctor_Specializations a join Doctors b on a.Doctor_ID = b.Doctor_ID where Doctor_Special = '"+textBox5.Text+"'", con.Connect());
            cmd.ExecuteNonQuery();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            gridView1.DataSource = dt;
        }

        private void comboBox2_Enter(object sender, EventArgs e)
        {
            gridView1.DataSource = null;
            dt = new DataTable();
            da = new SqlDataAdapter();
            cmd = new SqlCommand("select appointment_type_id, appointment_type_name from Appointment_Types", con.Connect());
            cmd.ExecuteNonQuery();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            gridView1.DataSource = dt;
        }

        private void comboBox3_Enter(object sender, EventArgs e)
        {
            gridView1.DataSource = null;
            dt = new DataTable();
            da = new SqlDataAdapter();
            cmd = new SqlCommand("select Lab_ID, Lab_Name from Labs", con.Connect());
            cmd.ExecuteNonQuery();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            gridView1.DataSource = dt;
        }

        private void emptydoc_Click(object sender, EventArgs e)
        {
            comboBox1.Text = null;
        }

      

        private void textBox5_Leave(object sender, EventArgs e)
        {
            comboBox1.Text = textBox5.Text;
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
