﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HospitalSystem
{
    public partial class Rooms_Add : Form
    {
        public Rooms_Add()
        {
            InitializeComponent();
        }

        private void Rooms_Add_Load(object sender, EventArgs e)
        {
            
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            new Rooms().Show();
            this.Hide();
        }
        RmClass rmc = new RmClass();
        private void Add_Pat_Details_btn_Click(object sender, EventArgs e)
        {
            try
            {
                rmc.insertRoom(int.Parse(comboBox1.Text), int.Parse(comboBox2.Text));
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
            
        }

        private void Clear_Btn_Click(object sender, EventArgs e)
        {
            comboBox1.Text = "";
            comboBox2.Text = "";
        }

        Connection con = new Connection();
        SqlCommand cmd;
        SqlDataAdapter da;
        DataTable dt = new DataTable();
        private void comboBox2_Enter(object sender, EventArgs e)
        {
            gridView1.DataSource = null;
            dt = new DataTable();
            da = new SqlDataAdapter();
            cmd = new SqlCommand("select Room_Type_ID, Room_Type from Room_Types", con.Connect());
            cmd.ExecuteNonQuery();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            gridView1.DataSource = dt;
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
