﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HospitalSystem
{
    public partial class Doctor_Add : Form
    {
        Connection con = new Connection();
        SqlCommand cmd = null;
        SqlDataAdapter da = null;
        public Doctor_Add()
        {
            InitializeComponent();
        }

        private void Doctor_Add_Load(object sender, EventArgs e)
        {

        }

        private void Add_btn_Click(object sender, EventArgs e)
        {
            try
            {
                Doctor_Add AddinPat = new Doctor_Add();
                cmd = new SqlCommand("insert into Doctors(Doctor_Name,Doctor_Gender,Doctor_Age,Doctor_Contact,Doctor_Qualification)values('"+Name_Txt.Text+"','"+Gender_Txt.Text+"',"+int.Parse(Age_Txt.Text)+","+int.Parse(Contact_Txt.Text)+",'"+Qualification_Txt.Text+"')", con.Connect());
                cmd.ExecuteNonQuery();
                da = new SqlDataAdapter(cmd);
                con.Close();
                MessageBox.Show("Successfully Added");

            }
            catch(Exception msg )
            {
                MessageBox.Show(msg.ToString());
            }
        }

        private void Clear_Btn_Click(object sender, EventArgs e)
        {
            Name_Txt.Text = "";
            Gender_Txt.Text = "";
            Age_Txt.Text = "";
            Contact_Txt.Text = "";
            Qualification_Txt.Text = "";
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            new Doctors().Show();
            this.Hide();
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
