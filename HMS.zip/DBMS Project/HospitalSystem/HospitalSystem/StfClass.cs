﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace HospitalSystem
{
    class StfClass
    {
        Connection con = new Connection();
        SqlCommand cmd = null;
        SqlDataAdapter da = null;
        DataTable dt = new DataTable();

        public DataTable ShowStaff()
        {
            cmd = new SqlCommand("select * from Staff", con.Connect());
            cmd.ExecuteNonQuery();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            return dt;
        }
        public void deleteStaff(int id)
        {
            try
            {
                cmd = new SqlCommand("delete from Staff where id=" + id + "", con.Connect());
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Staff deleted Successfully");
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message + "Staff Not Deleted");
            }
        }

        public void insertStaff(string stfname, string gender, int age, long stfcont)
        {
            try
            {
                cmd = new SqlCommand("insert into Staff values ('" + stfname + "','" + gender + "'," + age + "," + stfcont + ")", con.Connect());
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Staff Inserted !");
            }
            catch (Exception E)
            {
                MessageBox.Show("Staff Not Inserted \nReason\n" + E.Message);
                con.Close();
            }

        }

        public DataTable selectStfID(int id)
        {
            try
            {
                cmd = new SqlCommand("exec selectStfID " + id + "", con.Connect());
                cmd.ExecuteNonQuery();
                da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                con.Close();
                return dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in view Staff \nReason : " + ex.Message);
                con.Close();
            }
            return dt;
        }
    }
}
