﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalSystem
{
    public partial class Dorctor_Info : Form
    {
        public Dorctor_Info()
        {
            InitializeComponent();
        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            new Form1().Show();
            this.Hide();
        }

        DocClass dc = new DocClass();
        private void Dorctor_Info_Load(object sender, EventArgs e)
        {
            try
            {
                gridview1.DataSource = dc.showDoc();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }
        int id = 0;
        DcSpClass dsc = new DcSpClass();
        private void gridview1_Click(object sender, EventArgs e)
        {
            dsc = new DcSpClass();
            gridview2.DataSource = null;
            if (gridview1.SelectedRows.Count > 0)
            {
                int row = gridview1.CurrentRow.Index;
                DataGridViewRow selectedRow = gridview1.Rows[row];
                id = Convert.ToInt32(selectedRow.Cells["Doctor ID"].Value.ToString());
                gridview2.DataSource = dsc.DocSpecInfo(id);
            }
            else
            {
                MessageBox.Show("No Row Selected !");
            }
        }

        private void exit_btn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
