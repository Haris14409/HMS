﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalSystem
{
    public partial class Assign_Staff_Add : Form
    {
        public Assign_Staff_Add()
        {
            InitializeComponent();
        }

        private void Assign_Staff_Add_Load(object sender, EventArgs e)
        {
            
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            new AssignedStaff().Show();
            this.Hide();
        }
        AsynStfClass astfc = new AsynStfClass();
        private void Add_Pat_Details_btn_Click(object sender, EventArgs e)
        {
            try
            {
                astfc.insertStaffAssigned(int.Parse(comboBox1.Text), int.Parse(comboBox2.Text));
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
            
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
