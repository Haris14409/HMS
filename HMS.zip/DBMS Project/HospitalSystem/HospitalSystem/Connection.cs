﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;

namespace HospitalSystem
{
    //connection class 
    class Connection
    {
        //connection string
        string link = @"Data Source=DESKTOP-QS2O6RP\SQLEXPRESS;Initial Catalog=Hospital_MS;Integrated Security=True";
        //Zaryab Wala Project
        //if their is any connection already developed so make it null
        SqlConnection con = null;
        //connection string link thorugh constructor that when ever the obj is created then link will be given to sql class
        public Connection()
        {
            con = new SqlConnection(link);
        }
        //we will call this function when ever we want to establish the connection
        //fuction is a sql connection return type
        public SqlConnection Connect()
        {
            if (con != null)
            {
                con.Open();
            }
            return con;
        }
        //to close the connection this function is called
        public void Close()
        {
            con.Close();
        }

    }
}
