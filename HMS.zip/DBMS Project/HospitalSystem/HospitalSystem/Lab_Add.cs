﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HospitalSystem
{
    public partial class Lab_Add : Form
    {
        public Lab_Add()
        {
            InitializeComponent();
        }

        private void Clear_Btn_Click(object sender, EventArgs e)
        {
            Name_Txt.Text = "";
            Charg_Txt.Text = "";
            comboBox1.Text = "";
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            new Labs().Show();
            this.Hide();
        }
        LbClass lbc = new LbClass();
        private void Add_Lab_Details_btn_Click(object sender, EventArgs e)
        {
            try
            {
                lbc.LabAdd(Name_Txt.Text, Charg_Txt.Text, int.Parse(comboBox1.Text));
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }

        private void Lab_Add_Load(object sender, EventArgs e)
        {
            
        }
        Connection con = new Connection();
        SqlCommand cmd;
        SqlDataAdapter da;
        DataTable dt = new DataTable();
        private void comboBox1_Enter(object sender, EventArgs e)
        {
            gridView1.DataSource = null;
            dt = new DataTable();
            da = new SqlDataAdapter();
            cmd = new SqlCommand("select staff_id,staff_name from Staff", con.Connect());
            cmd.ExecuteNonQuery();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            gridView1.DataSource = dt;
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
